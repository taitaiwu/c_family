﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace WpfApp3___xiao_san_tong_ticket_booking
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
