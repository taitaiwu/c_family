﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Homework4___booking_system
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
